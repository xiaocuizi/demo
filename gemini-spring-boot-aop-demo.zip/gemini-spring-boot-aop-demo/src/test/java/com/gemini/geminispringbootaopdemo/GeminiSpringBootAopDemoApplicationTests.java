package com.gemini.geminispringbootaopdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeminiSpringBootAopDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
