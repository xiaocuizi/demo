package com.gemni.geminispringbootsentineldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeminiSpringBootSentinelDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeminiSpringBootSentinelDemoApplication.class, args);
	}

}
