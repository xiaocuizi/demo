package com.gemini.geminispringbootalgorithmdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeminiSpringBootAlgorithmDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
